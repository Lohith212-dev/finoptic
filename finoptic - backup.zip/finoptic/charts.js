/* ============================================================
   Finoptic — charts: every plot, drawn as plain SVG (§6)
   ------------------------------------------------------------
   Part of the mock-up's script set.  These files are plain <script> tags, not
   modules: every top-level binding is a shared global, so LOAD ORDER IS THE
   DEPENDENCY GRAPH.  index.html loads them as

     data/registry.js -> the four scenario-*.js -> logo.js -> icons.js ->
     brands.js -> core.js -> components.js -> charts.js -> tooltip.js ->
     people.js -> catalog.js -> screens.js -> screens-account.js ->
     screens-input.js -> screens-onboarding.js -> motion.js -> shell.js

   The screens-*.js files register themselves into the global S after the
   original seventeen; motion.js must precede shell.js because shell.js calls
   MOTION from go() and at boot.

   Nothing here runs at load time except in shell.js, which boots the app at its
   foot — so a function defined in one file may freely call one defined in a
   later file, as long as the call happens during a render.
   ============================================================ */

/* ============================================================
   Charts — plain SVG (§6)
   ============================================================ */
/* The categorical spectrum (§6), not a grey ramp.  Slot 1 is --accent, so the
   promoted series follows the brand; slots 2–8 are fixed hues that deliberately
   avoid green/amber/red (status colour is reserved, §0.5). */
const RAMP = ['--c1','--c2','--c3','--c4','--c5','--c6','--c7','--c8'];
/* Neutral, for a comparison baseline or an "all other" rollup — never a key. */
const NEUTRAL = '--g5';

/* Colour follows the entity (§2): a vendor, cloud provider, product or AI
   model keeps one fixed colour everywhere colour is the key.  Products in
   particular now get distinct slots wherever they are listed — they used to
   share one hue because bar lists were single-colour by rule. */
const ENTITY = {
  /* cloud providers */
  'AWS':'--c1', 'Amazon Web Services':'--c1',
  'Microsoft Azure':'--c2', 'Azure':'--c2', 'Google Cloud':'--c4',
  /* products */
  'Product Alpha':'--c1', 'Product Beta':'--c2', 'Product Gamma':'--c3',
  'Product Delta':'--c4', 'Product Epsilon':'--c5',
  'Shared services':'--c6', 'Shared platform':'--c6', 'Internal productivity':'--c7',
  'Internal IT':'--c7',
  /* AI providers and models */
  'OpenAI':'--c1', 'Microsoft 365 Copilot':'--c2', 'Anthropic':'--c3',
  'Google Gemini':'--c4', 'Azure OpenAI':'--c5', 'Perplexity':'--c6',
  'GitHub Copilot':'--c7',
  'All other vendors':'--c-other'
};
/* Entity -> colour.  Rollup rows carry their own count ("All other vendors (26)")
   and that count changes with the dataset, so they are matched by shape rather
   than listed — a rollup is never a colour key, it takes the neutral (§6). */
const ec = k => ENTITY[k] || (/^All other/.test(k||'') ? '--c-other' : null);

/* Unique gradient / pattern ids — several charts share one page. */
let gradUid = 0;
/* A diagonal-hatch <pattern>, the SVG twin of the CSS --hatch utility.  This is
   the reference set's signature texture (§6): it separates series without
   spending a second colour, which also makes it colour-blind safe. */
function hatchDef(colorVar,kind){
  const id = 'hx'+(++gradUid);
  const tpl = (typeof HATCH!=='undefined' && HATCH[kind||'template']) || null;
  if(!tpl) return {id:null,def:''};
  return {id, def: tpl.replace(/\{ID\}/g,id).replace(/\{COLOR\}/g,colorVar).replace(/\{OPACITY\}/g,'.5')};
}

/* ---------- hover / focus targets (see tooltip.js) ----------
   Every plot here was inert: a 1.75px stroke and a 2.4px dot are not things a
   pointer can find, so the charts read as pictures of data rather than as data.
   The target is the whole COLUMN, full plot height — anywhere in a month
   answers for that month — and it is emitted LAST so it sits over the paint.

   A chart's only job is to say WHAT is under the cursor; CHARTTIP owns how that
   reads.  `marks` are the crosshair and point dots for the answering column,
   and they ride inside the same <g> so the highlight is pure CSS with no
   per-frame JS and no state that can fall out of step with the panel.

   `fx-still` is motion.js's opt-out, and it is load-bearing rather than
   cosmetic: its entrance animation grows every <rect> in a plot from scaleY(0),
   so for the first half-second the area a hover is tested against would not be
   the area it looks like.  motion.js also infers "paints nothing" from computed
   style, but a band is fill:--ink at fill-opacity 0 — painted, just invisible —
   so it has to say so itself. */
const ctCol = (x,y,w,h,payload,marks='') =>
  `<g class="ct-col"><rect class="ct-band fx-still" x="${x}" y="${y}" width="${w}" height="${h}" ${CHARTTIP.attrs(payload)}/>${marks}</g>`;
const ctGuide = (x,y1,y2) => `<line class="ct-mk ct-guide" x1="${x}" x2="${x}" y1="${y1}" y2="${y2}"/>`;
const ctDot = (x,y,c) =>
  `<circle class="ct-mk" cx="${x}" cy="${y}" r="4" fill="var(--surface)" stroke="var(${c})" stroke-width="2"/>`;
/* An outline rather than a dot, where the mark for "this one" is a bar. */
const ctRing = (x,y,w,h) =>
  `<rect class="ct-mk fx-still" x="${x-2}" y="${y-2}" width="${w+4}" height="${h+4}" rx="3"
     fill="none" stroke="var(--ink)" stroke-opacity=".32" stroke-width="1.5"/>`;

function lineChart(series, labels, o={}){
  /* Taller by default than v3.1's 210.  Grid rows square off at the tallest card
     in the row, so a chart drawn short leaves a visible void under itself in a
     card sized by its neighbour. */
  const W=o.w||680, H=o.h||244, L=44, R=12, Tp=12, B=24;
  const all = series.flatMap(s=>s.values).filter(v=>v!==null&&v!==undefined);
  if(!all.length) return emptyState('No data in this period','Widen the period filter to see a trend.');
  const max = o.max || Math.ceil(Math.max(...all)*1.12/10)*10, min=0;
  const x = i => L + i*((W-L-R)/(labels.length-1));
  const y = v => Tp + (H-Tp-B)*(1-(v-min)/(max-min));
  const ticks=[0,.25,.5,.75,1].map(t=>min+(max-min)*t);
  /* Gradient area fill (§6): series colour at 28% under the line, fading to
     nothing at the baseline.  28 rather than 35 because slot 1 is a warm hue —
     orange at 35% over a tall plot area stops being a fill and becomes the
     subject. */
  let defs='';
  series.forEach(s=>{
    if(!s.area) return;
    s.grad = 'fill'+(++gradUid);
    defs+=`<linearGradient id="${s.grad}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" style="stop-color:var(${s.color});stop-opacity:.28"/>
      <stop offset="1" style="stop-color:var(${s.color});stop-opacity:0"/></linearGradient>`;
  });
  /* Painted in three passes so the hairline grid still reads through the fill. */
  let areas='', g='';
  series.forEach(s=>{
    if(!s.area) return;
    const pts = s.values.map((v,i)=>v===null||v===undefined?null:[x(i),y(v)]).filter(Boolean);
    if(pts.length<2) return;
    const d = pts.map((p,i)=>(i?'L':'M')+p[0]+' '+p[1]).join(' ');
    areas+=`<path d="${d} L${pts[pts.length-1][0]} ${y(0)} L${pts[0][0]} ${y(0)} Z" fill="url(#${s.grad})"/>`;
  });
  ticks.forEach(t=>{g+=`<line class="gridline" x1="${L}" x2="${W-R}" y1="${y(t)}" y2="${y(t)}"/>
    <text class="axis" x="${L-8}" y="${y(t)+3}" text-anchor="end">${o.fmt?o.fmt(t):'$'+Math.round(t)+'K'}</text>`});
  labels.forEach((l,i)=>{g+=`<text class="axis" x="${x(i)}" y="${H-8}" text-anchor="middle">${l}</text>`});
  series.forEach(s=>{
    const pts = s.values.map((v,i)=>v===null||v===undefined?null:[x(i),y(v)]).filter(Boolean);
    if(!pts.length) return;
    const d = pts.map((p,i)=>(i?'L':'M')+p[0]+' '+p[1]).join(' ');
    g+=`<path d="${d}" fill="none" stroke="var(${s.color})" stroke-width="${s.w||1.75}" ${s.dash?`stroke-dasharray="4 3"`:''} stroke-linejoin="round"/>`;
    if(s.dots) pts.forEach(p=>g+=`<circle cx="${p[0]}" cy="${p[1]}" r="2.4" fill="var(--surface)" stroke="var(${s.color})" stroke-width="1.5"/>`);
  });
  /* One band per x-index, half a step either side of the point.  A trend chart
     with three lines is the case that most needed this: reading "actual against
     plan against forecast for March" off three crossing strokes was guesswork,
     and the panel lists all three against one label. */
  const step = (W-L-R)/Math.max(1,labels.length-1);
  let hit='';
  labels.forEach((l,i)=>{
    const rows = series.map(s=>{
      const v = s.values[i];
      return (v===null||v===undefined) ? null
        : {n:s.name, v:(o.fmt?String(o.fmt(v)):moneyK(v)), c:s.color};
    }).filter(Boolean);
    if(!rows.length) return;
    const bx = Math.max(L, x(i)-step/2), bw = Math.min(W-R, x(i)+step/2) - bx;
    const marks = ctGuide(x(i),Tp,H-B) + series.map(s=>{
      const v = s.values[i];
      return (v===null||v===undefined) ? '' : ctDot(x(i),y(v),s.color);
    }).join('');
    hit += ctCol(bx,Tp,bw,H-Tp-B,{t:l,r:rows},marks);
  });
  return `<svg viewBox="0 0 ${W} ${H}"><defs>${defs}</defs>${areas}${g}${hit}</svg>
  <div class="legend">${series.map(s=>`<div><i style="background:var(${s.color});${s.dash?'height:2px;border-radius:0':''}"></i>${s.name}</div>`).join('')}</div>`;
}

function stackedBars(labels, series, o={}){
  const W=o.w||680,H=o.h||244,L=44,R=12,Tp=12,B=24;
  const totals = labels.map((_,i)=>series.reduce((s,x)=>s+(x.values[i]||0),0));
  /* `!totals.length` first.  Math.max() of NOTHING is -Infinity, which is
     truthy, so a series with no columns at all sailed past this guard and
     drew an axis labelled $-InfinityK. */
  if(!totals.length || !Math.max(...totals))
    return emptyState('No data in this period','Widen the period filter.');
  const max = Math.ceil(Math.max(...totals)*1.12/10)*10;
  const bw = (W-L-R)/labels.length*0.62;
  const cx = i => L + (i+0.5)*((W-L-R)/labels.length);
  const y = v => Tp+(H-Tp-B)*(1-v/max);
  /* Bars carry a vertical gradient — a shade lighter at the top — and the
     series after the first is hatched over its own colour, so the stack reads
     apart even in the mono palette or in print (§6). */
  let defs='';
  series.forEach((s,si)=>{
    s.grad='bar'+(++gradUid);
    defs+=`<linearGradient id="${s.grad}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" style="stop-color:color-mix(in srgb, var(${s.color}) 74%, #fff)"/>
      <stop offset="1" style="stop-color:var(${s.color})"/></linearGradient>`;
    if(si%2===1){ const h = hatchDef(s.color,'template'); s.hatch = h.id; defs += h.def; }
  });
  let g='';
  [0,.25,.5,.75,1].forEach(t=>{const v=max*t;g+=`<line class="gridline" x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}"/>
    <text class="axis" x="${L-8}" y="${y(v)+3}" text-anchor="end">$${Math.round(v)}K</text>`});
  labels.forEach((l,i)=>{
    let acc=0;
    series.forEach(s=>{
      const v=s.values[i]||0; const h=(H-Tp-B)*v/max;
      if(v){
        g+=`<rect x="${cx(i)-bw/2}" y="${y(acc+v)}" width="${bw}" height="${h}" fill="url(#${s.grad})"/>`;
        if(s.hatch) g+=`<rect x="${cx(i)-bw/2}" y="${y(acc+v)}" width="${bw}" height="${h}" fill="url(#${s.hatch})"/>`;
      }
      acc+=v;
    });
    g+=`<text class="axis" x="${cx(i)}" y="${H-8}" text-anchor="middle">${l}</text>`;
  });
  /* A band's share of its own month is the thing a stack is actually asked —
     "how much of March was Azure" — and it cannot be read off the plot at all,
     so every row carries it and the footer carries the column total. */
  const colw = (W-L-R)/labels.length;
  let hit='';
  labels.forEach((l,i)=>{
    const tot = totals[i];
    if(!tot) return;
    const rows = series.map(s=>{
      const v = s.values[i]||0;
      return v ? {n:s.name, v:moneyK(v), c:s.color, d:share(v,tot)} : null;
    }).filter(Boolean);
    if(!rows.length) return;
    hit += ctCol(L+i*colw, Tp, colw, H-Tp-B,
      {t:l, r:rows, f:{n:'Total', v:moneyK(tot)}},
      ctRing(cx(i)-bw/2, y(tot), bw, (H-Tp-B)*tot/max));
  });
  return `<svg viewBox="0 0 ${W} ${H}"><defs>${defs}</defs>${g}${hit}</svg>
  <div class="legend">${series.map(s=>`<div><i style="background:var(${s.color})"></i>${s.name}</div>`).join('')}</div>`;
}

/* ---- RANKED ORDER (§6) ----
   "Any plot, table, or numeric display should be ordered in descending order… if a
   tile shows spend by vendor, the entities within it should be listed from highest
   to lowest."

   Applied HERE, inside the three functions that draw ranked things, rather than at
   the ~40 call sites that feed them.  Two reasons, and they are the same two that
   put the table's sorting on the rendered cells: forty edits are forty chances for
   one list to be left in whatever order its dataset happened to hold, and a dataset
   loaded from a file at runtime cannot be edited at a call site at all.  Sorting at
   the point of drawing means every ranked list in the product obeys the rule, and a
   scenario author cannot break it by accident.

   `tail:true` pins a row to the bottom.  One list — the overview's vendors — ends
   in a rolled-up "All other vendors (26)" row, and that row is a REMAINDER rather
   than a rank: if the tail happened to outweigh the eighth vendor it would sort
   above it and the list would read as though "all other vendors" were a vendor.

   STABLE, because Array.prototype.sort is only guaranteed stable for the comparator
   returning 0 — equal values keep their authored order, which is what stops two
   $0K rows from swapping places between renders of the same screen.

   NOT applied to lineChart, stackedBars, bandChart or waterfall: those four are
   ordered by time or by the steps of an equation, and "descending" there would mean
   running the year backwards or reordering the terms of a sum. */
const ranked = items => (items||[]).slice().sort((a,b)=>
  (a.tail?1:0) - (b.tail?1:0) || (b.v||0) - (a.v||0));

/* Donut (§6): centre total in the hero-number face, legend as a mini-table. */
function donut(items,o={}){
  /* Ranked, so the biggest slice starts at twelve o'clock and the ring reads
     clockwise by size.  The legend beside it runs the identical comparator (see
     legend() in components.js) — if only one of the two sorted, the third row of
     the key would name the fourth slice of the ring. */
  items = ranked(items);
  const total = items.reduce((s,i)=>s+i.v,0);
  if(!total) return emptyState('Nothing to break down','No spend falls inside the current filters.');
  const S=o.size||168, r=S/2-4, ir=o.ir||r*0.62, cx=S/2, cy=S/2;
  let a=-Math.PI/2, g='';
  items.forEach((it,idx)=>{
    const sw = it.v/total*Math.PI*2, b=a+sw;
    const p = (rad,ang)=>[cx+rad*Math.cos(ang), cy+rad*Math.sin(ang)];
    const [x1,y1]=p(r,a),[x2,y2]=p(r,b),[x3,y3]=p(ir,b),[x4,y4]=p(ir,a);
    const col = it.g||ec(it.k)||RAMP[idx%8];
    /* The slice is its own hit target — a ring segment is already generous, so
       there is nothing to gain from an invisible wedge on top of it, and one
       fewer node per slice keeps the legend and the plot reading as one thing.
       Share charts answer "what is this, how much, what fraction". */
    g+=`<path class="ct-slice" d="M${x1} ${y1} A${r} ${r} 0 ${sw>Math.PI?1:0} 1 ${x2} ${y2} L${x3} ${y3} A${ir} ${ir} 0 ${sw>Math.PI?1:0} 0 ${x4} ${y4} Z"
      fill="var(${col})" stroke="var(--surface)" stroke-width="1.5"
      ${CHARTTIP.attrs({t:it.k, c:col, v:moneyK(it.v),
        d:share(it.v,total)+' of '+money(total)+' '+(o.label||'total')})}/>`;
    a=b;
  });
  g+=`<text x="${cx}" y="${cy-2}" text-anchor="middle" class="donut-total">${money(total)}</text>
      <text x="${cx}" y="${cy+11}" text-anchor="middle" class="axis">${o.label||'YTD'}</text>`;
  return `<svg class="ct-donut" viewBox="0 0 ${S} ${S}" style="width:${S}px;margin:0 auto">${g}</svg>`;
}

/* Horizontal breakdown bars.
   Where every row names a known entity — products, cloud providers, vendors —
   the list takes the ENTITY colours and shows a brand mark or a swatch, because
   colour follows the entity (§2).  Products used to share one hue here, which
   is exactly the "everything is the same colour" fault.  Where rows are plain
   labels (services, savings sources) the list stays single-hue and gradients
   from soft accent to full accent, with `o.highlight` promoting one row. */
function hbars(items,o={}){
  if(!items.length) return emptyState('Nothing to rank','No rows fall inside the current filters.');
  /* Highest first.  This is the list the instruction names by example, and it is
     also the list `o.highlight` indexes into — so the sort has to happen before the
     index is read, which is why it is the first statement in the function and not
     folded into the map below. */
  items = ranked(items);
  const max = Math.max(...items.map(i=>i.v)) || 1;
  const total = items.reduce((s,i)=>s+i.v,0);
  const entityMode = o.entity!==false && items.every(i=>i.g||ec(i.k));
  const marks = o.marks!==false && items.some(i=>hasBrand(i.k));
  const fill = (i,idx) =>
    (i.g||ec(i.k)) && entityMode ? `background:var(${i.g||ec(i.k)})`
      : o.highlight===idx
        ? `background:linear-gradient(90deg,var(--accent),var(--accent-strong))`
        : `background:linear-gradient(90deg,var(--accent-soft),var(--accent))`;
  /* The whole ROW is the hit target, not the bar inside it — an 8px bar clipped
     to a fraction of the track is the narrowest thing on the screen, and a row
     whose name is ellipsised is exactly the row you want a readout for.  Rank is
     the one fact the list shows implicitly and never states. */
  const tip = (i,idx) => CHARTTIP.attrs({
    t:i.k, c:((i.g||ec(i.k)) && entityMode) ? (i.g||ec(i.k)) : '--accent',
    v:moneyK(i.v), d:share(i.v,total)+' of '+money(total),
    f:{n:'Rank', v:(idx+1)+' of '+items.length}
  });
  return rowList(items.map((i,idx)=>`
    <div class="row" ${tip(i,idx)}>
      <div class="grow">
        <div class="t">${marks?entityMark(i.k):(entityMode?swatch(i.k):'')}<span>${i.k}</span></div>
        <div class="bar"><i class="${o.highlight===idx?'':'hatched'}" style="width:${i.v/max*100}%;${fill(i,idx)}"></i></div>
      </div>
      <div class="v">${moneyK(i.v)}<div class="d" style="font-weight:400">${share(i.v,total)}</div></div>
    </div>`), o.noun || 'rows');
}

function waterfall(steps,o={}){
  const W=o.w||680,H=o.h||252,L=48,R=12,Tp=14,B=52;
  let run=0; const pts=[];
  steps.forEach(s=>{
    if(s.type==='base'){pts.push({k:s.k,from:0,to:s.v,type:'base'});run=s.v;}
    else if(s.type==='total'){pts.push({k:s.k,from:0,to:s.v,type:'total'});}
    else {pts.push({k:s.k,from:run,to:run+s.v,type:s.type,delta:s.v});run+=s.v;}
  });
  /* ZERO-BASED, like every other chart here.
     A broken axis was built for this chart and reverted on sight: when a variance
     walk opens at ~$1.5M and closes at ~$1.62M, starting the axis below the walk
     does make each $30-90K step legible — but it also turns two totals into
     truncated columns, and a bar chart whose bars do not start at zero has to be
     read carefully rather than glanced at.  On a screen a client reads in a
     minute, glanceable and honest beats legible and qualified.
     The cost is accepted and known: the anchors dominate, the steps are small,
     and the card carries some slack because extra height goes into the empty
     middle rather than into the bars.  Don't reintroduce the break without
     asking — it has been tried. */
  /* A walk of zeros has a maximum of zero, and every y() below divides by
     it — NaN coordinates draw nothing at all, so the card came out blank
     rather than saying it had nothing to show. */
  const peak = pts.length ? Math.max(...pts.map(p=>Math.max(p.from,p.to))) : 0;
  if(peak <= 0) return emptyState('Nothing to reconcile yet',
    'A variance walk needs a closed month on both sides of it.');
  const max = Math.ceil(peak*1.06/50)*50;
  const bw=(W-L-R)/pts.length*0.6, cx=i=>L+(i+0.5)*((W-L-R)/pts.length);
  const y=v=>Tp+(H-Tp-B)*(1-v/max);
  let g='';
  [0,.5,1].forEach(t=>{const v=max*t;g+=`<line class="gridline" x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}"/>
    <text class="axis" x="${L-8}" y="${y(v)+3}" text-anchor="end">$${Math.round(v)}K</text>`});
  pts.forEach((p,i)=>{
    const top=y(Math.max(p.from,p.to)), h=Math.max(2,Math.abs(y(p.to)-y(p.from)));
    /* Anchors (opening, closing) stay neutral ink so the coloured steps between
       them are what the eye follows; the steps run at full status brightness. */
    const fill = p.type==='base'||p.type==='total'?'var(--g2)':p.type==='up'?'var(--neg)':'var(--pos)';
    g+=`<rect x="${cx(i)-bw/2}" y="${top}" width="${bw}" height="${h}" rx="2" fill="${fill}"/>`;
    if(i<pts.length-1) g+=`<line x1="${cx(i)+bw/2}" x2="${cx(i+1)-bw/2}" y1="${y(p.to)}" y2="${y(p.to)}" stroke="var(--line-2)" stroke-dasharray="2 2"/>`;
    const lab = p.type==='up'||p.type==='down'?(p.delta>0?'+':'−')+Math.abs(p.delta):Math.round(p.to);
    g+=`<text class="axis strong" x="${cx(i)}" y="${top-5}" text-anchor="middle">${lab}</text>`;
    const words=p.k.split(' ');
    g+=`<text class="axis" x="${cx(i)}" y="${H-B+16}" text-anchor="middle">${words[0]}</text>`;
    if(words[1]) g+=`<text class="axis" x="${cx(i)}" y="${H-B+27}" text-anchor="middle">${words.slice(1).join(' ')}</text>`;
  });
  /* The zero-based axis is the reason this chart needs a readout most: the
     anchors dominate and every step between them is a sliver, so the number the
     step is worth is legible in the panel long before it is legible in the bar.
     The band runs the full height INCLUDING the two label lines, because on a
     walk the label is what you aim at. */
  const colw=(W-L-R)/pts.length;
  let hit='';
  pts.forEach((p,i)=>{
    const top=y(Math.max(p.from,p.to)), h=Math.max(2,Math.abs(y(p.to)-y(p.from)));
    const rows = (p.type==='base'||p.type==='total')
      ? [{n:'Total', v:money(p.to), c:'--g2'}]
      : [{n:p.delta>0?'Adds':'Returns', v:signed(p.delta), c:p.type==='up'?'--neg':'--pos'},
         {n:'Running total', v:money(p.to)}];
    hit += ctCol(L+i*colw, Tp, colw, H-Tp, {t:p.k, r:rows}, ctRing(cx(i)-bw/2, top, bw, h));
  });
  return `<svg viewBox="0 0 ${W} ${H}">${g}${hit}</svg>`;
}

function bandChart(o){
  const W=o.w||680,H=o.h||268,L=48,R=14,Tp=14,B=24;
  const labels=D.meta.months.concat(['Aug','Sep','Oct']);
  const closed=D.meta.closed;
  const act=D.trend.actual.slice(0,closed).concat(new Array(15-closed).fill(null));
  const last=D.trend.actual.filter(v=>v!==null).slice(-1)[0]||0;
  /* new Array(-1) throws RangeError, and an exception here killed the whole
     render — sidebar and all — rather than one card.  A forecast needs a
     closed month to project from, so say so instead. */
  if(closed < 1) return emptyState('No forecast yet',
    'A projection needs at least one closed month to run from.');
  const pad=n=>new Array(closed-1).fill(null).concat(n);
  const base=pad([last,Math.round(last*.99),Math.round(last*1.01),Math.round(last*1.04),Math.round(last*1.06)]);
  const up  =pad([last,Math.round(last*1.04),Math.round(last*1.09),Math.round(last*1.14),Math.round(last*1.19)]);
  const dn  =pad([last,Math.round(last*.94),Math.round(last*.93),Math.round(last*.91),Math.round(last*.90)]);
  const max = Math.ceil(Math.max(...up.filter(v=>v!==null),...act.filter(v=>v!==null))*1.15/20)*20;
  const x=i=>L+i*((W-L-R)/(labels.length-1)), y=v=>Tp+(H-Tp-B)*(1-v/max);
  let g='';
  [0,.25,.5,.75,1].forEach(t=>{const v=max*t;g+=`<line class="gridline" x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}"/>
    <text class="axis" x="${L-8}" y="${y(v)+3}" text-anchor="end">$${Math.round(v)}K</text>`});
  labels.forEach((l,i)=>g+=`<text class="axis" x="${x(i)}" y="${H-8}" text-anchor="middle">${l}</text>`);
  const seg=arr=>arr.map((v,i)=>v===null||v===undefined?null:[x(i),y(v)]).filter(Boolean);
  const U=seg(up),Dn=seg(dn);
  /* The confidence band is the accent at low alpha — it belongs to the actual
     series it brackets, so it takes that series' hue rather than a grey. */
  if(U.length&&Dn.length)
    g+=`<path d="${U.map((p,i)=>(i?'L':'M')+p[0]+' '+p[1]).join(' ')} ${Dn.slice().reverse().map(p=>'L'+p[0]+' '+p[1]).join(' ')} Z" fill="var(--c1)" opacity=".14"/>`;
  /* Dashed ghost line for the comparison series, neutral against the actual. */
  const line=(arr,col,dash)=>{const s=seg(arr);if(!s.length)return;
    g+=`<path d="${s.map((p,i)=>(i?'L':'M')+p[0]+' '+p[1]).join(' ')}" fill="none" stroke="var(${col})" stroke-width="1.75" ${dash?'stroke-dasharray="4 3"':''}/>`};
  line(base,'--g4',true); line(act,'--c1',false);
  g+=`<line x1="${x(closed-1)}" x2="${x(closed-1)}" y1="${Tp}" y2="${H-B}" stroke="var(--line-2)"/>
      <text class="axis" x="${x(closed-1)+5}" y="${Tp+9}">forecast →</text>`;
  /* The band's width IS the message on this chart ("±4% in July, ±14% by
     October"), and a shaded region has no readable edge — so the column states
     the two bounds as a figure rather than leaving them to be eyeballed. */
  const step=(W-L-R)/Math.max(1,labels.length-1);
  let hit='';
  labels.forEach((l,i)=>{
    const rows=[];
    if(act[i]!==null&&act[i]!==undefined) rows.push({n:'Actual',v:moneyK(act[i]),c:'--c1'});
    if(base[i]!==null&&base[i]!==undefined) rows.push({n:'Baseline forecast',v:moneyK(base[i]),c:'--g4'});
    if(up[i]!==null&&up[i]!==undefined&&dn[i]!==null&&dn[i]!==undefined)
      rows.push({n:'Range',v:moneyK(dn[i])+' – '+moneyK(up[i])});
    if(!rows.length) return;
    const bx=Math.max(L,x(i)-step/2), bw=Math.min(W-R,x(i)+step/2)-bx;
    const marks = ctGuide(x(i),Tp,H-B)
      + (act[i]!==null&&act[i]!==undefined?ctDot(x(i),y(act[i]),'--c1'):'')
      + (base[i]!==null&&base[i]!==undefined?ctDot(x(i),y(base[i]),'--g4'):'');
    hit += ctCol(bx,Tp,bw,H-Tp-B,{t:l,r:rows},marks);
  });
  return `<svg viewBox="0 0 ${W} ${H}">${g}${hit}</svg>
  <div class="legend"><div><i style="background:var(--c1)"></i>Actual</div>
  <div><i style="background:var(--g4);height:2px;border-radius:0"></i>Baseline forecast</div>
  <div><i style="background:var(--c1);opacity:.25"></i>Upper / lower range</div></div>`;
}

function flowDiagram(){
  const stages=[['Technology data sources','12 systems'],['FinOps data platform','Normalise & ingest'],
                ['Allocation & enrichment','Tags, owners, rates'],['Analytics','Trend, unit cost, variance'],
                ['Optimisation','Backlog & savings'],['Persona dashboards','4 audiences']];
  const W=980,H=132,bw=140,gap=(W-stages.length*bw)/(stages.length-1);
  let g='', hit='';
  stages.forEach((s,i)=>{
    const x=i*(bw+gap);
    g+=`<rect x="${x}" y="34" width="${bw}" height="60" rx="6" fill="var(--surface)" stroke="var(--line-2)"/>
        <text class="axis" x="${x+bw/2}" y="52" text-anchor="middle">0${i+1}</text>`;
    const words=s[0].split(' '); const l1=words.slice(0,2).join(' '), l2=words.slice(2).join(' ');
    g+=`<text x="${x+bw/2}" y="70" text-anchor="middle" style="font-size:11px;font-weight:700;fill:var(--ink)">${l1}</text>
        <text x="${x+bw/2}" y="83" text-anchor="middle" style="font-size:10px;fill:var(--ink-2)">${l2||s[1]}</text>`;
    if(i<stages.length-1) g+=`<path d="M${x+bw+4} 64 L${x+bw+gap-6} 64" stroke="var(--line-2)" stroke-width="1"/>
        <path d="M${x+bw+gap-10} 60.5 L${x+bw+gap-5} 64 L${x+bw+gap-10} 67.5" fill="var(--ink-4)"/>`;
    /* Not a plot, so this gets a readout for one specific reason: a stage whose
       name runs to three words spends the box's second line on the rest of the
       name, and its description ("Tags, owners, rates") is dropped entirely.
       Hovering is where that sentence went. */
    hit+=`<g class="ct-col"><rect class="ct-band fx-still" x="${x}" y="34" width="${bw}" height="60" rx="6"
       ${CHARTTIP.attrs({t:s[0], d:s[1]})}/></g>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}">${g}${hit}</svg>`;
}
