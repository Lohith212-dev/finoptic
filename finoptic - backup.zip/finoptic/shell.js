/* ============================================================
   Finoptic — shell: icons, sidebar, filters, the reconciliation strip, routing, boot
   ------------------------------------------------------------
   Part of the mock-up's script set.  These files are plain <script> tags, not
   modules: every top-level binding is a shared global, so LOAD ORDER IS THE
   DEPENDENCY GRAPH.  index.html loads them as

     data/registry.js -> the four scenario-*.js -> logo.js -> icons.js ->
     brands.js -> core.js -> components.js -> charts.js -> tooltip.js ->
     people.js -> catalog.js -> screens.js -> screens-account.js ->
     screens-input.js -> screens-onboarding.js -> motion.js -> shell.js

   The screens-*.js files register themselves into the global S after the
   original seventeen; motion.js must precede shell.js because shell.js calls
   MOTION from go() and at boot.

   Nothing here runs at load time except in shell.js, which boots the app at its
   foot — so a function defined in one file may freely call one defined in a
   later file, as long as the call happens during a render.
   ============================================================ */

/* ============================================================
   Navigation, filters, chrome, routing
   ============================================================ */
/* ---- icons (§5) -------------------------------------------------------------
   The set itself is in icons.js: the real Heroicons 24px SOLID set, fetched from
   tailwindlabs/heroicons, one file per glyph, path data untouched.  It used to be
   ~40 hand-drawn stroke glyphs defined right here.  They were consistent with
   each other and with nothing else, and at the 14px they are mostly used at they
   read as sketched: "the current icons do not look great; please fix them."
   Inline rather than an icon font because the mock-up opens by double-click from
   a file:// path with no network, so a CDN webfont is not an option.
   Vendor logos are NOT icons and are not here — they carry their own literal
   colours, so they live in brands.js as BRANDS and render via brandMark(). */
const icon = (name,sm) => ICONS[name]
  ? `<svg class="ic${sm?' sm':''}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]}</svg>` : '';
/* The four group glyphs — the ONLY icons in the sidebar now that the items
   beneath them are plain text. */
const groupIcon = name => (typeof GROUP_ICONS_SOLID!=='undefined' && GROUP_ICONS_SOLID[name])
  ? `<svg class="ic gi" viewBox="0 0 24 24" aria-hidden="true">${GROUP_ICONS_SOLID[name]}</svg>`
  : `<span class="gi"></span>`;
/* Fills the static data-icon / data-logo placeholders in index.html, so a glyph
   and the logo artwork each live in exactly one place. */
function fillChrome(root=document){
  root.querySelectorAll('[data-icon]').forEach(n=>{
    n.innerHTML = icon(n.dataset.icon, n.dataset.size==='sm');
  });
  root.querySelectorAll('[data-logo]').forEach(n=>{
    n.innerHTML = (typeof LOGO!=='undefined' && LOGO[n.dataset.logo]) || '';
  });
}

/* Sidebar structure.  The Overview group holds ONE screen and the View line.
   It used to hold five: Executive overview, then IT financial management,
   Finance, Procurement and Products — the same four names the View dropdown
   directly above them already listed, so the group was the dropdown written out
   twice.  The four are reachable only through the dropdown now, which is what it
   is for: those screens ARE the four lenses.

   A `Dynamic Overview` row was tried here for one round, as an alias resolving to
   the active lens's home.  It existed only to give the rail a second visible
   overview while the lens switch was away on the page head; with the switch back
   in the rail directly below, the row was naming the same destination the line
   under it already names, which is the duplication this group has been trimmed
   for twice before.  Removed.
   Items carry no icon; the group header does. */
const NAV = [
  ['Overview',[['overview','Executive Overview']]],
  /* Observability was removed outright, and ITSM moved up to fourth: the group
     now runs from the two biggest lines (cloud, AI) through the two that are
     bought per seat and per ticket, and ends on security. */
  ['Spend',[['cloud','Cloud'],['ai','AI'],['saas','SaaS & Licences'],
            ['itsm','ITSM'],['security','Security']]],
  ['Manage',[['forecast','Budgets & Forecasts'],['allocation','Cost Allocation'],
             ['optimize','Optimisation'],['anomalies','Anomalies'],
             ['alerts','Alerts'],['add','Add A Record'],['team','Team & Access']]],
  /* Getting started sits ABOVE Data model: they are the same chain in opposite
     directions.  Data model explains how a dollar becomes a decision once every
     feed is in; Getting started is that chain told forwards, to a workspace
     where none of them are. */
  ['Reference',[['onboarding','Getting Started'],['sources','Data Model']]]
];

/* The four views, and the screen each one opens on.  `label` is what the View
   dropdown shows; these four screens have no nav row of their own. */
/* `blurb` exists for the View picker's option list.  A bare list of four nouns
   made the reader guess what "Products" would show them; one line of what the
   lens is FOR is the difference between a dropdown and a menu. */
const PERSONA = {
  itfm:{home:'itfm', label:'IT Financial Management', short:'ITFM', focus:['itfm','cloud','ai','allocation','optimize','forecast'],
        blurb:'Unit economics, cloud and AI cost, allocation'},
  finance:{home:'finance', label:'Finance', short:'Finance', focus:['finance','forecast','allocation','anomalies','overview'],
        blurb:'Budget, variance, forecast and accruals'},
  proc:{home:'proc', label:'Procurement', short:'Procurement', focus:['proc','saas','ai','optimize'],
        blurb:'Vendors, contracts, renewals and licences'},
  biz:{home:'product', label:'Products', short:'Products', focus:['product','ai','cloud','alerts'],
        blurb:'Cost per product, per customer, and margin'}
};

/* Screen → title.  The four persona screens are not in NAV any more, so their
   titles come from PERSONA — Export and the state URL both need them. */
const TITLES = {};
NAV.forEach(g=>g[1].forEach(i=>TITLES[i[0]]=i[1]));
Object.keys(PERSONA).forEach(k=>{ TITLES[PERSONA[k].home] = PERSONA[k].label; });
/* A persona screen belongs to Overview, because that is where its View line is —
   which is what keeps the Overview group marked as active while you are on one. */
const groupOf = id => (NAV.find(g=>g[1].some(i=>i[0]===id))||['Overview'])[0];
const personaOf = id => Object.keys(PERSONA).find(k=>PERSONA[k].home===id) || null;

let current = 'overview', persona = 'itfm';
/* Which groups are folded.  EVERYTHING EXCEPT OVERVIEW starts folded: the
   Executive overview is the default screen, so Overview is the only group whose
   contents you are already looking at, and the other three are places you might
   go rather than places you are.  A sidebar that opens with all seventeen items
   showing spends its whole height telling you about screens you did not ask for.
   Overview also has to be the open one because the `View:` line lives on its
   rail — folding it would hide the persona switch behind a click.
   In memory only: a demo shouldn't remember a folded group from an earlier
   session and look broken on open. */
const shutGroups = new Set(NAV.map(g=>g[0]).filter(n=>n!=='Overview'));

/* Sidebar (§8) — grouped tree rail.  Each group is an icon + a sentence-case
   header, larger than its own items, with a collapse caret; the items hang off a
   single faint trunk by rounded elbows (the elbows are CSS, per-item ::before).

   Items are TEXT.  Every one of them used to carry its own glyph as well as the
   group carrying one, which is seventeen icons plus four in a 276px column:
   "everything currently has an icon, which creates visual overload."

   THE `View:` LINE IS BACK, and it sits third in the Overview group, under the two
   rows it governs.  It moved onto the page head for one round and came straight
   back — "revert the persona dropdown change and move it back into the sidebar as
   it was before" — so it is the same SPLIT control it was before that: the name
   opens the lens's home, the caret opens the picker.  That split is not decoration;
   a single button that only opened a menu was the original complaint ("the view
   itself should be clickable"), and making the whole control navigate instead would
   remove the only way to switch.  Large target for the common act, its own target
   for the rare one.

   It is also the ONLY thing in the rail that can show you are on one of the four
   lens screens, since those four have no row of their own — which is why it lights
   with the active wash via personaOf() rather than by an id match. */
function renderNav(){
  const p = PERSONA[persona];
  const viewLine = `<div class="navitem viewline${personaOf(current)?' on':''}">
    <em>View</em>
    <span class="viewpick">
      <button type="button" class="viewpick-go" data-go-view
              title="Open ${p.label}"><b>${p.label}</b></button>
      <button type="button" class="viewpick-more" data-view-menu
              aria-haspopup="listbox" aria-expanded="false"
              title="Switch view" aria-label="Switch view">${icon('caret',true)}</button>
    </span></div>`;
  document.getElementById('navgroups').innerHTML = NAV.map(g=>{
    const items = g[1].map(i=>{
      const on = i[0]===current, focus = p.focus.includes(i[0]);
      return `<button class="navitem${on?' on':''}" data-go="${i[0]}" title="${i[1]}">
        <span class="lbl">${i[1]}</span>${
        focus&&!on?'<span class="focusdot" title="Relevant to this view"></span>':''}</button>`;
    });
    if(g[0]==='Overview') items.push(viewLine);
    const active = groupOf(current)===g[0] || (g[0]==='Overview' && personaOf(current));
    return `<div class="navgroup${shutGroups.has(g[0])?' shut':''}${active?' active':''}">
      <button type="button" data-group="${g[0]}" aria-expanded="${!shutGroups.has(g[0])}" title="${g[0]}">
        ${groupIcon(g[0])}<span>${g[0]}</span><span class="caret">${icon('caret',true)}</span>
      </button>
      <div class="rail">${items.join('')}</div>
    </div>`;
  }).join('');
}

/* ---- filters (§7) ----
   Only the dimensions the current screen can honour are rendered, which is what
   holds the bar to one row.  Each pill is a real dropdown over the values in
   the ACTIVE dataset, so switching scenario changes the options too. */
function renderFilters(){
  const dims = activeDims();
  const wrap = document.getElementById('filters');
  /* A screen may emit no controls row at all — sign-in is the whole window, with
     no filters to offer and no "as of" line to carry. */
  if(!wrap) return;
  if(!dims.length){
    wrap.innerHTML = `<span class="asof">${NO_FILTER_NOTE[current]
      || 'No filters apply on this screen.'}</span>`;
  } else {
    wrap.innerHTML = dims.map(d=>{
      const vals = sel(d), set = d!=='period' && vals.length>0;
      /* "Cloud infrastructure +2" rather than "3 selected".  A count alone makes
         you open the menu to find out what you picked, which defeats the pill. */
      const text = d==='period' ? shortPeriod(F.period)
        : !set ? 'All'
        : vals.length===1 ? vals[0]
        : vals[0]+' +'+(vals.length-1);
      /* PERIOD IS THE PRIMARY CONTROL and is always dressed as one: "the period
         filter is the most important because the entire dashboard updates based
         on the selected period, and users need to be aware of this.  Currently it
         lacks visual emphasis."  It is also the only dimension that can never be
         cleared — every figure on every screen is a figure FOR a span of months —
         so unlike the others it has no unset state to be quiet in, and dressing
         it permanently is honest rather than shouty. */
      return `<span class="chipwrap">
        <button class="chip ${d==='period'
            ? 'primary'+(F.period===CUSTOM_PERIOD?' custom':'') : ''} ${set?'set':''}" data-dim="${d}"
                aria-haspopup="listbox" aria-expanded="false">
          ${icon(DIMS[d].icon,true)}
          ${/* The dimension name is dropped when the value already starts with
                it, or the Product pill reads "Product Product Beta". */''}
          ${String(text).indexOf(DIMS[d].label)===0?'':`<em>${DIMS[d].label}</em>`}<b>${text}</b>
          ${set?'<span class="x" data-clear="'+d+'" role="button" aria-label="Clear '+DIMS[d].label+'">×</span>'
               :'<span class="caret">'+icon('caret',true)+'</span>'}
        </button></span>`;
    }).join('') + (liveFilters().length
      ? `<button class="filter-clear" id="clear-filters">Clear ${liveFilters().length}</button>` : '');
  }
  const est = D.estimated ? ' · filtered' : '';
  document.getElementById('asof').textContent =
    `As of ${D.meta.asOf} · ${(D.sources||[]).length||12} sources${est}`;
}
/* The pill has room for the span, not for the fiscal-year gloss around it. */
const shortPeriod = v => v===CUSTOM_PERIOD
  ? (F.range ? rangeSummary(F.range) : 'Custom')
  : (v.split(' · ')[1] || v.replace(' · Aug–Jun',''));
/* What a custom range actually resolved to.  Months, not dates, because months
   are what it resolved to — see rangeMonths(). */
function rangeSummary(r){
  const ms = rangeMonths(r), M = RAW.meta.months;
  if(!ms.length) return 'Custom';
  return ms.length===1 ? M[ms[0]] : M[ms[0]]+'–'+M[ms[ms.length-1]];
}

/* ---- the reconciliation strip (§7) ----
   The equation is the strip.  Spend − budget = variance, at 28px, on the left,
   with nothing above it competing for the reading: the "Budget reconciliation"
   label that used to sit there was telling the reader what an equation is.
   Three stats follow at 15px, right-aligned, each named by its own label —
   there were four under a "Position" heading, which is one stat and one heading
   more than the row could hold.  "Realised" folded into the savings cell's
   sub-line, where it belongs: it is a share of that figure, not a peer of it.

   Returned as a string, not written into a slot in the shell, because head()
   emits it — that is what puts the page title above it (see head()).
   The collapse state lives on <html data-ledger>, so it survives every
   re-render without being tracked here. */
const ledgerMin = () => document.documentElement.getAttribute('data-ledger')==='min';
const ledgerTip = () => ledgerMin()
  ? 'Show the full reconciliation bar' : 'Hide the reconciliation bar';

/* The four tones a counterfoil stat can take.  Amber is the one status role whose
   bright mark is unreadable as text at any size, so `warn` takes the deeper ink
   step (§2); `neg` is the only one that uses the bright mark, because a variance
   figure is the one place on the ticket where red IS the message. */
const LEDGER_TONE = {
  pos:'color:var(--pos-ink)', warn:'color:var(--warn-ink)',
  neg:'color:var(--neg)',     '':''
};

function ledgerStrip(stats){
  /* A WORKSPACE THAT HAS CLOSED NOTHING GETS THE EM-DASH STRIP, not a row of
     zeroes.  "$0K − $0K = +$0K, +0.0% on plan" is the strip stating, in the
     product's loudest component and on every screen, that the company spent
     nothing and is exactly on plan — where the truth is that no month has closed
     and neither term exists yet.  freshLedger() is the same component with the
     figures it cannot know shown as dashes; it was written for the day-one
     preview and this is the same day.  The KPI tiles took the same treatment in
     kpi(), so the strip and the board beneath it agree. */
  if(typeof workspaceEmpty==='function' && workspaceEmpty() && typeof freshLedger==='function')
    return freshLedger();
  const varAmt = D.ytdActual - D.ytdBudget;
  const varPct = D.ytdBudget ? (varAmt/D.ytdBudget*100) : 0;
  const conv = D.identified ? Math.round(D.realized/D.identified*100) : 0;
  const cell = (k,v,sub,style='') => `<div class="ledger-cell">
    <span class="ledger-k">${k}</span>
    <span class="ledger-v" style="${style}">${v}</span>
    ${sub?`<span class="ledger-sub">${sub}</span>`:''}</div>`;
  /* Collapsed, the labels above each figure are hidden, so the terms are named
     inline instead — the row still reads as a sentence rather than three loose
     numbers.  Both sets are always in the DOM; CSS shows one. */
  const op = (o,word) => `<div class="ledger-op" aria-hidden="true">${o}`
    + (word?`<span class="ledger-inline"> ${word} </span>`:'') + `</div>`;

  return `<div class="ledger">
    <div class="ledger-eq">
      <span class="ledger-inline">Spend</span>
      ${/* The months ACTUALLY summed, not the dataset's closed count.  The two
            agree on the default full year and disagree the moment a period is
            chosen — a May–Jun figure captioned "11 months" is the strip
            contradicting the filter directly above it. */''}
      ${(()=>{ const n = monthsOf(F.period).length;
         return cell('Spend',money(D.ytdActual), n+(n===1?' month':' months')); })()}
      ${op('−','budget')}
      ${cell('Budget',money(D.ytdBudget),'phased plan')}
      ${op('=','variance')}
      ${cell('Variance',(varAmt>=0?'+':'−')+money(Math.abs(varAmt)),
        (varAmt>=0?'+':'−')+Math.abs(varPct).toFixed(1)+'% '+(varAmt>0?'over':varAmt<0?'under':'on')+' plan',
        varAmt>0?'color:var(--neg)':varAmt<0?'color:var(--pos)':'')}
      <span class="ledger-inline">${(varAmt>=0?'+':'−')+Math.abs(varPct).toFixed(1)}% ${varAmt>0?'over':varAmt<0?'under':'on'} plan</span>
    </div>
    ${/* The ticket's perforation.  It is a real element between the two halves
          rather than a background drawn at a fixed percentage, because the
          equation flexes with the window and a painted-on line would drift off
          the seam the moment the figures changed width. */''}
    <div class="ledger-perf" aria-hidden="true"></div>
    <div class="ledger-stats">${
      /* PER-SCREEN, and visible collapsed as well as expanded.  It used to be the
         same three figures on all sixteen screens, which meant the procurement
         board carried the executive overview's counterfoil — and collapsed, the
         whole right-hand half of the ticket was empty: "in the collapsed view we
         have only the equation on the left, and the entire right side is empty.  We
         want to use this right space for important stats."

         The stats are PASSED IN by the screen rather than looked up here, and that
         is the decision worth defending.  Almost every one of them mirrors a KPI
         tile on the same screen — Uncommitted Spend, Consolidation Savings, Cost Per
         Ticket — and those tiles are computed from locals in the renderer's own
         scope (`committed`, `consolSave`, `me`, `secTotal`).  A registry here would
         have had to recompute all of it, and the two copies would drift the first
         time a formula changed; there is no way to notice that drift except by
         reading both.  Passing them means the strip and the tile are the SAME
         expression evaluated once, and a harness can assert they still match.
         Screens that pass nothing keep the estate-level three. */
      (stats && stats.length ? stats : [
        ['Forecast Year-End', money(D.fyForecast), signed(D.fyForecast-D.fyBudget)+' vs budget'],
        ['Identified Savings', money(D.identified), money(D.realized)+' realised · '+conv+'%', 'pos'],
        /* Amber is the one status role whose bright mark is unreadable as text at
           any size, so this cell takes the deeper ink step (§2). */
        ['Unallocated', money(D.unallocated), share(D.unallocated,D.ytdActual)+' of spend', 'warn']
      ]).map(([k,v,sub,tone])=>cell(k,v,sub,LEDGER_TONE[tone]||'')).join('')
    }</div>
    <button class="iconbtn ledger-toggle tip tip-up" id="ledger-toggle"
            data-tip="${ledgerTip()}" aria-label="${ledgerTip()}">${icon('caret')}</button>
  </div>`;
}

/* ---- toast (§7) — Export and Share are real actions, so they confirm. ---- */
/* Top RIGHT, and a stack.  It was one reused element pinned bottom-right, which
   had two faults: a second confirmation inside four seconds overwrote the first
   without either being read, and the bottom-right corner is the one place on a
   long screen a reader is not looking — the action they just took was at the top.
   "The current toast messages feel dead and lack liveliness."
   Each toast is its own element with its own timer, so three actions produce
   three cards that clear independently, and each carries a draining bar so the
   time left is visible rather than guessed at.
   Dismissible, because a toast that covers the Export button it is confirming
   should not have to be waited out. */
const TOAST_MS = 4200;
function toast(title,sub,tone){
  const wrap = document.getElementById('toasts');
  const t = document.createElement('div');
  t.className = 'toast-item' + (tone?' '+tone:'');
  t.innerHTML = `<span class="toast-ic">${icon(tone==='warn'?'alerts':'check')}</span>`
    + `<div class="toast-t"><b>${title}</b>${sub?`<span>${sub}</span>`:''}</div>`
    + `<button class="toast-x" type="button" aria-label="Dismiss">&times;</button>`
    + `<i class="toast-bar" style="animation-duration:${TOAST_MS}ms"></i>`;
  wrap.appendChild(t);
  document.getElementById('live').textContent = title + (sub?'. '+sub:'');
  /* Oldest first: a stack that grows without limit will eventually cover the
     board, and the newest message is the one being read. */
  while(wrap.children.length > 3) dropToast(wrap.firstElementChild);
  const timer = setTimeout(()=>dropToast(t), TOAST_MS);
  t.addEventListener('click', e=>{
    if(!e.target.closest('.toast-x')) return;
    clearTimeout(timer); dropToast(t);
  });
}
/* Removed on a TIMER, not on animationend.  Under prefers-reduced-motion the
   stylesheet kills every animation outright, so animationend never fires and a
   toast waiting for it would stay on screen for ever. */
function dropToast(t){
  if(!t || t.dataset.going) return;
  t.dataset.going = '1';
  t.classList.add('going');
  setTimeout(()=>t.remove(), 260);
}

/* ---- export (§7) ----
   Was a dead button.  Now writes two real files: every table visible on the
   screen as CSV, and the active dataset as JSON — the same shape the "Load a
   dataset" picker reads back, so the round trip is real. */
function download(name,text,type){
  const url = URL.createObjectURL(new Blob([text],{type}));
  const a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 1000);
}
const csvCell = s => {
  /* Whitespace is COLLAPSED, not just trimmed.  These cells are built from
     template literals whose own source indentation reaches the DOM as real
     newlines, and a newline inside a field forces CSV quoting — so a single cell
     arrived in Excel as three lines of a quoted block. */
  const v = String(s).replace(/<[^>]*>/g,'')
    .replace(/ /g,' ').replace(/\s+/g,' ').trim();
  return /[",\n]/.test(v) ? '"'+v.replace(/"/g,'""')+'"' : v;
};
/* Text as a READER sees it.  A raw textContent read was fine while a cell held a
   string; it stopped being fine once cells started holding components.  An
   avatar puts the initials "SM" in the DOM immediately before the name, so the
   owner column exported "SMS. Menon", and the middots separating an anomaly's
   provider, product and date arrived as data.  Everything decorative is already
   marked aria-hidden for screen readers — which is exactly the set a spreadsheet
   does not want either. */
function cellText(node){
  const c = node.cloneNode(true);
  c.querySelectorAll('[aria-hidden="true"]').forEach(n=>n.remove());
  return c.textContent;
}
/* A row list is not a table, so its "columns" have to be inferred.  A disclosure
   row keeps its summary inside the button that opens it; a plain row keeps it in
   its own children, where a control (Resolve) is a control and not a column. */
function rowCells(r){
  const head = r.querySelector(':scope > button[aria-expanded]');
  const src = head || r;
  return [...src.children]
    .filter(n => !(n.tagName === 'BUTTON' && n !== head))
    .map(n => csvCell(cellText(n)));
}
function exportView(){
  const tables = [...document.querySelectorAll('#screen table')];
  const scope = liveFilters().map(d=>DIMS[d].label+'='+sel(d).join('/'))
    .concat([F.period===CUSTOM_PERIOD ? 'Custom · '+rangeSummary(F.range) : F.period]).join(' · ');
  let csv = ['Finoptic — '+TITLES[current], 'Dataset,'+RAW.label, 'Scope,'+csvCell(scope),
             'Generated as of,'+D.meta.asOf, ''].join('\n')+'\n';
  tables.forEach((t,i)=>{
    const heading = t.closest('.card')?.querySelector('.card-h h3')?.textContent || ('Table '+(i+1));
    csv += heading+'\n';
    csv += [...t.querySelectorAll('tr')]
      .map(tr=>[...tr.children].map(td=>csvCell(cellText(td))).join(',')).join('\n')+'\n\n';
  });
  /* Row lists are data too.  Export only ever walked <table>s, so once the
     anomalies screen replaced its ten-column table with disclosure rows its CSV
     carried a heading and nothing else — and the alerts feed, which has never
     been a table, had been exporting nothing since the day the button was
     wired.  A row whose direct child is a button is a disclosure row, and that
     button holds the summary line. */
  const lists = [...document.querySelectorAll('#screen .rows')];
  lists.forEach((l,i)=>{
    const heading = l.closest('.card')?.querySelector('.card-h h3')?.textContent || ('List '+(i+1));
    csv += heading+'\n';
    csv += [...l.querySelectorAll(':scope > .row')]
      .map(r=>rowCells(r).join(',')).join('\n')+'\n\n';
  });
  const stamp = D.meta.asOf.replace(/ /g,'-');
  /* BOM.  The file is UTF-8 and says so in its MIME type, but Excel ignores that
     for CSV and decodes as the system codepage — so every em dash in a screen
     title or an opportunity name arrived as "â€"" and every middot as "Â·".
     A leading U+FEFF is the only thing Excel reads as "this is UTF-8", and it is
     harmless to every other consumer. */
  download(`finoptic-${current}-${RAW.id}-${stamp}.csv`, '﻿'+csv, 'text/csv;charset=utf-8');
  download(`finoptic-dataset-${RAW.id}.json`, JSON.stringify(RAW,null,2), 'application/json');
  const blocks = tables.length + lists.length;
  toast('Exported '+blocks+' block'+(blocks===1?'':'s'),
        'CSV of this screen, plus the full dataset as JSON.');
}

/* ---- share (§7) ----
   Also a dead button before.  Builds a URL that restores everything that makes
   this view what it is — dataset, screen, view, filters — and copies it.  The
   clipboard API can be refused on a file:// origin, so there are two fallbacks
   and, failing both, the link is shown for manual copying. */
function stateUrl(){
  const p = new URLSearchParams();
  p.set('s',RAW.id); p.set('v',persona);
  /* Multi-select values ride as a comma-joined list.  None of the dataset's
     category, product, provider, environment or vendor names contains a comma,
     which is what makes the cheap encoding safe rather than merely convenient —
     if one ever does, this has to become a repeated key. */
  MULTI.forEach(k=>{ if(has(k)) p.set(k, sel(k).join(',')); });
  if(F.period!==PERIODS[0][0]) p.set('period', F.period);
  if(F.period===CUSTOM_PERIOD && F.range) p.set('range', F.range.from+'~'+F.range.to);
  return location.href.split('#')[0] + '#' + current + '?' + p.toString();
}
function shareView(){
  const url = stateUrl();
  const done = () => toast('Link copied',
    'Restores this dataset, screen, view and '+(liveFilters().length||'no')+' filter'+(liveFilters().length===1?'':'s')+'.');
  const manual = () => toast('Copy this link', url);
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(url).then(done).catch(()=>legacyCopy(url)?done():manual());
  } else { legacyCopy(url)?done():manual(); }
}
function legacyCopy(text){
  try{
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly',''); ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    const ok = document.execCommand('copy'); ta.remove(); return ok;
  }catch(e){ return false; }
}

/* ---- scenario loading (§10) ---- */
function loadScenario(id,keepFilters){
  const s = FINOPTIC.list.find(x=>x.id===id) || FINOPTIC.list[0];
  RAW = clone(s);
  RAW.scenarios = RAW.scenarios || [];
  reconcile();
  /* Vendor → brand-mark lookup, rebuilt per dataset (§5). */
  VENDOR_BRAND = {};
  (RAW.vendors||[]).forEach(v=>{ if(v.brand) VENDOR_BRAND[v.k]=v.brand; });
  (RAW.saas||[]).forEach(a=>{ if(a.brand) VENDOR_BRAND[a.vendor]=a.brand; });
  /* The setup walkthrough belongs to the WORKSPACE, so it is re-derived when the
     workspace changes.  It used to open with step 01 marked done in every
     dataset, which is right for a workspace with figures in it — the feeds are
     visibly landing — and flatly wrong for one that has closed nothing: the
     empty workspace showed eight em dashes under a walkthrough claiming its cost
     feed was connected, and the connect pane opened on "Done".  Two things
     describing one workspace have to agree. */
  if(typeof onbSyncToDataset==='function') onbSyncToDataset();
  if(!keepFilters){ MULTI.forEach(k=>F[k]=[]); F.period = PERIODS[0][0]; F.range = null; }
  /* The tone dot now rides on the profile menu's dataset row rather than on a
     pill in the top bar. */
  const pick = document.getElementById('scenario-pick');
  pick.className = 'menu-row ' + (RAW.tone||'');
  const sel = document.getElementById('scenario');
  sel.innerHTML = FINOPTIC.list.map(x=>
    `<option value="${x.id}"${x.id===RAW.id?' selected':''}>${x.label}</option>`).join('');
  document.getElementById('notif-count').textContent = String((RAW.alerts||[]).length);
}

/* ---- render ---- */
/* ---- the insight band's position (§7) ----
   "Immediately after the filter rows appear the Reconciliation bar, followed by
   the insights bar and the KPI tiles… move the key insights below the KPI tiles."

   Done by MOVING THE NODE rather than by changing what head() emits, and that is
   the decision worth defending.  head() emitting all four parts of the page head
   in one place is what keeps the order right on twenty screens without twenty
   edits — the note above it says so — and it cannot emit the band after the tiles,
   because the tiles are the first children of a grid each screen builds itself.
   The alternatives were: pass the band into every screen (twenty call sites, and
   twenty chances for one to put it somewhere else), or split it out of head() and
   have each grid open with it (same cost).  One generic move, applied once per
   render, keeps head() authoritative and costs one function.

   It runs BEFORE MOTION.afterScreen, so the band is already in the grid when the
   entrance animation counts children and therefore animates in sequence with the
   tiles rather than ahead of them.

   The leading RUN of KPI tiles is what it inserts after — not "the first
   non-KPI", because two screens open with a card and then show tiles further
   down, and the band belongs under the tiles that answer the headline, not
   halfway down the board. */
/* What the summary panel is ABOUT, per screen.  Short noun phrases rather than the
   page title, because the title is 30px above it and repeating it would waste the
   one line the panel gets.  The active period joins it on screens that offer the
   period pill — which is most of them, and is the same emphasis the pill itself
   just gained: the reader should not have to hunt for which months these numbers
   are.  Screens with no period pill get the noun alone rather than a span they
   cannot change. */
const SUM_SUBJECT = {
  overview:'Technology Spend',        itfm:'The Technology Estate',
  cloud:'Cloud Spend',               ai:'AI Spend',
  saas:'Subscriptions And Licences', finance:'Budget And Variance',
  proc:'Vendors And Contracts',      product:'Cost Per Product',
  optimize:'The Savings Backlog',    allocation:'Traceable Spend',
  forecast:'The Year-End Position',  anomalies:'Unexpected Movement',
  alerts:'Open Decisions',           security:'Security Spend',
  itsm:'Service Desk Economics',     sources:'The Data Behind The Numbers'
};
function summaryHead(){
  const n = SUM_SUBJECT[current] || TITLES[current] || 'This Screen';
  return activeDims().includes('period') ? n + ' · ' + shortPeriod(F.period) : n;
}

/* Which tab is showing.  On <html>, like data-ledger, so it survives every
   re-render without being tracked here — and defaults to the insight view, which
   is what the reader is meant to land on: "the default view should be the
   key-insight view, the black tile view." */
const SUM_TABS = [['insights','Key Insights'],['metrics','Metrics']];
const sumTab = () => document.documentElement.getAttribute('data-sum') || 'insights';

/* ---- the summary panel (§7) ----
   "Collapse the KPI tiles and summary into one tabbed view with two tabs… the tabs
   should be in the same row, and the default view should be the key-insight view."

   THE HEADER IS CHROME, NOT A CARD.  The headline and the tab switcher sit on the
   canvas above both panes, and each pane is its own surface — "I want the heading
   and the tab switcher outside these panes, with the actual cards placed in their
   grouped-state pane."  A first version wrapped the whole thing in one white card
   with the ink band flush inside it, which made the header part of the object it was
   labelling; pulling it out means the tabs read as a control over two surfaces
   rather than as a title bar belonging to one.  It also lets the KPI tiles go back
   to being ordinary cards on the canvas in their own pane, which is what they are.

   The insight pane carries a footnote link out of itself: "add a footnote-style
   textual button labeled 'View KPIs' that switches to the metrics view."  It is the
   only route between the two that does not require finding the tabs, and it sits
   where the reader finishes reading.

   Built by MOVING the two nodes head() and the screen already produced, for the
   same reason placeBriefing() did before it: head() composing the page head in one
   place is what keeps twenty screens consistent, and the KPI tiles are the first
   children of a grid each screen builds itself.  One generic assembly costs one
   function; the alternative is twenty call sites that can each disagree.

   It runs BEFORE MOTION.afterScreen, so the panel is in the DOM when the entrance
   animation indexes boxes.

   Degrades rather than half-builds.  A screen with tiles but no insight band — the
   account and data-entry screens, which use their own head functions — keeps its
   tiles in the grid untouched, because a two-tab control with one empty tab is
   worse than no control. */
function placeSummary(){
  const host = document.getElementById('screen');
  const grid = host && host.querySelector(':scope > .grid');
  const band = host && host.querySelector(':scope > .briefing');
  if(!grid || !band) return;
  const lead = [];
  for(const el of grid.children){
    if(!el.classList.contains('kpi')) break;
    lead.push(el);
  }
  if(!lead.length) return;

  const tab = sumTab();
  const wrap = document.createElement('section');
  wrap.className = 'sum';
  wrap.innerHTML = `<div class="sum-h">
      <h2>${summaryHead()}</h2>
      <div class="sum-tabs" role="tablist" aria-label="Summary view">${
        SUM_TABS.map(([k,label])=>`<button type="button" class="sum-tab${k===tab?' on':''}"
          role="tab" aria-selected="${k===tab}" data-sum-tab="${k}">${label}</button>`).join('')}
      </div>
    </div>
    <div class="sum-pane" data-sum-pane="insights" role="tabpanel"></div>
    <div class="sum-pane" data-sum-pane="metrics" role="tabpanel"><div class="sum-kpis"></div></div>`;
  grid.parentNode.insertBefore(wrap, grid);
  wrap.querySelector('[data-sum-pane="insights"]').appendChild(band);
  const met = wrap.querySelector('.sum-kpis');
  lead.forEach(el=>met.appendChild(el));
  /* Inside the band, spanning its three columns, so it reads as the band's own
     footer rather than as a button parked underneath it.  It carries
     `data-sum-tab`, which is all the switch handler below matches on — so the
     footnote and the tab are the same control with two presentations. */
  band.insertAdjacentHTML('beforeend',
    `<button type="button" class="sum-more" data-sum-tab="metrics">View KPIs
       <span aria-hidden="true">›</span></button>`);
}

/* The tabs. Delegated on document, because the panel is rebuilt on every render —
   a listener bound to the buttons would be attached to nodes the next filter change
   throws away. Writing the attribute is all it takes; CSS shows the pane. */
document.addEventListener('click', e=>{
  const t = e.target.closest('[data-sum-tab]');
  if(!t) return;
  const k = t.dataset.sumTab;
  document.documentElement.setAttribute('data-sum', k);
  /* Matched on the VALUE, not on identity, because the clicked element is not always
     one of the tabs — the "View KPIs" footnote carries the same attribute, and
     comparing nodes would have switched the pane while leaving both tabs unlit. */
  const box = t.closest('.sum');
  if(box) box.querySelectorAll('.sum-tab').forEach(b=>{
    const on = b.dataset.sumTab === k;
    b.classList.toggle('on', on);
    b.setAttribute('aria-selected', on);
  });
});

function go(id,push=true){
  if(!S[id]) id='overview';
  /* Only a real navigation unfolds a group, not a re-render.  refresh() calls
     go(current), so unfolding unconditionally would re-open a group the user had
     just folded every time they touched a filter. */
  const moved = id !== current;
  current = id;
  /* A screen may declare that it wants no shell around it.  Only sign-in does —
     it is the screen you have not yet entered the product from, so a sidebar
     full of screens you cannot open would be a lie.  Declared on the renderer
     itself (`S.signin.chrome = 'bare'`) so a screen owns the decision rather
     than the shell keeping a list of exceptions. */
  document.documentElement.setAttribute('data-chrome', (S[id] && S[id].chrome) || 'full');
  /* You cannot be inside a folded group: arriving at a screen — from the nav, a
     shared link or the View switch — reveals where you are.  For the four persona
     screens groupOf() answers Overview, which is where their View line is. */
  if(moved) shutGroups.delete(groupOf(id));
  /* Landing on a persona screen — from a shared link, or from the View
     dropdown — IS switching view, so the dropdown must follow.  It is the only
     thing in the sidebar that can show you are there. */
  const pv = personaOf(id);
  if(pv) persona = pv;
  D = deriveView();
  /* Motion is OPTIONAL and lives in motion.js.  These three calls are the whole
     contract: the shell does not know what an animation is, and the mock-up must
     still render correctly if motion.js is missing or has been switched off for
     prefers-reduced-motion. */
  if(window.MOTION) MOTION.beforeScreen(id, moved);
  /* head() emits the ledger strip, so it renders with the screen rather than
     into a slot in the shell — which is how the page title got above it. */
  document.getElementById('screen').innerHTML = S[id]();
  placeSummary();
  renderNav(); renderFilters();
  /* The controls row is re-created on every render, so the observer has to be
     re-pointed at the new element rather than left watching a detached one. */
  watchStick();
  if(window.MOTION) MOTION.afterScreen(id, moved);
  /* Only a real navigation returns you to the top.  A filter change re-renders
     the same screen, and jumping to the top there both loses your place and —
     because the scroll listener closes popovers — slams shut the multi-select
     menu you are in the middle of using. */
  if(moved) window.scrollTo({top:0,behavior:'instant'});
  if(push){
    const h = stateUrl().split('#')[1];
    if(location.hash.slice(1)!==h) history.replaceState(null,'','#'+h);
  }
}
/* A filter or scenario change is just a re-render of the same screen. */
const refresh = () => go(current);

/* ---- popover plumbing ---- */
/* Only the things that OPEN one of these menus get their aria-expanded reset.
   It used to reset every `[aria-expanded="true"]` in the document with a
   data-group exemption bolted on, which is a blocklist — so the moment a screen
   grew a disclosure button of its own (an anomaly card, a form section) this
   silently told the world it had collapsed while it sat there open, and the next
   click on it inverted.  A list of the triggers this function is actually
   responsible for cannot go wrong that way. */
const MENU_TRIGGERS = '.chip[data-dim], [data-view-menu], [data-pick], #profile-btn';
function closeMenus(except){
  document.querySelectorAll('.menu').forEach(m=>{ if(m!==except) m.hidden = true; });
  document.querySelectorAll(MENU_TRIGGERS).forEach(b=>b.setAttribute('aria-expanded','false'));
  document.querySelectorAll('.menu.vals').forEach(m=>m.remove());
}
/* A filter pill's value list is built on demand from the ACTIVE dataset, so it
   can never offer a value the loaded scenario doesn't contain.
   PORTALLED TO <body>, position:fixed, anchored to the pill's on-screen rect.
   Appended to the pill it was invisible: .filters was overflow-x:auto, and CSS
   promotes the other axis to auto alongside it, so the row clipped its own
   children on both axes and a 300px-tall menu opened inside a 34px-tall
   clipping box.  The pills responded to every click; the menu was being cut
   away — which is exactly the "the filters are not working, and they are not
   clickable" symptom.  Out here nothing can clip it. */
function openDimMenu(chip,dim){
  const m = document.createElement('div');
  m.className = 'menu vals dimmenu' + (dim==='period'?' periodmenu':' multimenu');
  m.dataset.forDim = dim;
  m.innerHTML = dim==='period' ? periodMenuHTML() : multiMenuHTML(dim);
  m.addEventListener('click', e=>{
    /* PERIOD is single-select and closes on choice: a period is one span of time,
       so picking a second one is a replacement, not an addition. */
    if(dim==='period'){
      if(e.target.closest('[data-custom]')){ openRangeMenu(chip); return; }
      const o = e.target.closest('[data-val]'); if(!o) return;
      F.period = o.dataset.val; F.range = null;
      closeMenus(); refresh(); return;
    }
    /* Everything else is multi-select and STAYS OPEN.  Closing after each pick
       would make choosing three products three round trips through the pill,
       which is the whole thing multi-select exists to avoid. */
    if(e.target.closest('[data-all]')){ F[dim] = []; syncMulti(m,dim); refresh(); return; }
    const o = e.target.closest('[data-val]'); if(!o) return;
    const v = o.dataset.val, cur = sel(dim);
    F[dim] = cur.includes(v) ? cur.filter(x=>x!==v) : cur.concat([v]);
    /* Selecting every value says the same thing as selecting none, and an
       "everything" filter that still reads as filtered would make the Clear
       count and the cards' "estimated" marks both lie. */
    if(F[dim].length === allOf(dim).length) F[dim] = [];
    syncMulti(m,dim); refresh();
  });
  m.addEventListener('input', e=>{
    if(!e.target.matches('[data-opt-find]')) return;
    const q = e.target.value.trim().toLowerCase();
    m.querySelectorAll('.menu-opt[data-val]').forEach(b=>{
      b.hidden = !!q && !b.dataset.val.toLowerCase().includes(q);
    });
  });
  document.body.appendChild(m);
  chip.setAttribute('aria-expanded','true');
  placeMenu(m, chip);
  const find = m.querySelector('[data-opt-find]'); if(find) find.focus();
}
/* Repaints the menu's own state after a toggle.  The menu lives on <body>, so a
   re-render of the screen leaves it standing — which is what lets it stay open
   across a refresh, and also why its tick marks have to be updated by hand. */
function syncMulti(m,dim){
  const on = sel(dim);
  m.querySelectorAll('.menu-opt[data-val]').forEach(b=>{
    b.classList.toggle('on', on.includes(b.dataset.val));
    b.setAttribute('aria-selected', String(on.includes(b.dataset.val)));
  });
  const all = m.querySelector('[data-all]');
  if(all) all.classList.toggle('on', on.length===0);
  const n = m.querySelector('[data-opt-count]');
  if(n) n.textContent = on.length ? on.length+' of '+allOf(dim).length : 'All';
}
const OPT_FIND_MIN = 8;
function multiMenuHTML(dim){
  const vals = allOf(dim), on = sel(dim);
  return `<div class="menu-h opt-h"><span>${DIMS[dim].label}</span>
      <span data-opt-count>${on.length?on.length+' of '+vals.length:'All'}</span></div>
    ${vals.length>=OPT_FIND_MIN?`<label class="opt-find">${icon('filter',true)}
      <input type="search" data-opt-find placeholder="Find a ${DIMS[dim].label.toLowerCase()}"
             aria-label="Find a ${DIMS[dim].label.toLowerCase()}"></label>`:''}
    <button class="menu-opt opt-all ${on.length?'':'on'}" type="button" data-all
      >All ${DIMS[dim].label.toLowerCase()}s</button>
    <div class="menu-sep"></div>
    ${vals.map(v=>`<button class="menu-opt opt-multi ${on.includes(v)?'on':''}"
        type="button" data-val="${v}" role="option" aria-selected="${on.includes(v)}">
        <span class="tick" aria-hidden="true"></span>
        ${ec(v)?`<i style="background:var(${ec(v)})"></i>`:''}
        <span class="opt-n">${v}</span></button>`).join('')}`;
}
function periodMenuHTML(){
  return `<div class="menu-h">Period</div>`
    + PERIODS.map(p=>`<button class="menu-opt ${F.period===p[0]?'on':''}" type="button" data-val="${p[0]}">
        <span class="opt-n">${p[0]}</span><span class="cnt">${p[1].length} mo</span></button>`).join('')
    + `<div class="menu-sep"></div>
       <button class="menu-opt opt-custom ${F.period===CUSTOM_PERIOD?'on':''}" type="button" data-custom>
         ${icon('calendar',true)}<span class="opt-n">Custom range…</span></button>`;
}

/* ---- the custom range calendar (§7) ----
   Two month grids, prev/next, click a start then an end.

   Clamped to the CLOSED months of the fiscal year, and it says so.  A picker
   that let you reach March 2024 on a dataset beginning in August 2025 would be
   offering a query the data cannot answer, and one that reached into the
   forecast month would fold a projection into an "actual" total — on a screen
   whose entire claim is that the numbers reconcile.
   It also resolves to WHOLE MONTHS and prints what it resolved to, because the
   dataset carries one figure per month.  Interpolating a daily curve to honour
   "the 12th to the 27th" would be the most convincing lie in the mock-up. */
let calFrom = null, calTo = null, calCursor = null;
function openRangeMenu(anchor){
  closeMenus();
  const lo = fyMonthStart(0), hi = fyMonthEnd(closedCount()-1);
  calFrom = F.range ? new Date(F.range.from+'T00:00:00') : null;
  calTo   = F.range ? new Date(F.range.to+'T00:00:00')   : null;
  const seed = calFrom || hi;
  calCursor = new Date(seed.getFullYear(), seed.getMonth(), 1);
  /* Two grids are drawn at once, so the cursor never sits on the final month or
     the right-hand grid would fall outside the window. */
  const lastCursor = new Date(hi.getFullYear(), hi.getMonth()-1, 1);
  if(calCursor > lastCursor) calCursor = lastCursor;
  if(calCursor < new Date(lo.getFullYear(), lo.getMonth(), 1))
    calCursor = new Date(lo.getFullYear(), lo.getMonth(), 1);
  const m = document.createElement('div');
  m.className = 'menu vals calmenu';
  m.dataset.forDim = '__range';
  document.body.appendChild(m);
  drawCal(m, lo, hi);
  m.addEventListener('click', e=>{
    const step = e.target.closest('[data-cal-step]');
    if(step){
      calCursor = new Date(calCursor.getFullYear(), calCursor.getMonth()+ +step.dataset.calStep, 1);
      drawCal(m, lo, hi); return;
    }
    const day = e.target.closest('[data-day]:not([disabled])');
    if(day){
      const d = new Date(day.dataset.day+'T00:00:00');
      /* A second click always ENDS the range unless it lands before the start,
         in which case the user is plainly restarting rather than picking
         backwards. */
      if(!calFrom || calTo || d < calFrom){ calFrom = d; calTo = null; }
      else calTo = d;
      drawCal(m, lo, hi); return;
    }
    if(e.target.closest('[data-cal-cancel]')){ closeMenus(); return; }
    if(e.target.closest('[data-cal-apply]:not([disabled])')){
      F.period = CUSTOM_PERIOD;
      F.range = {from:isoDay(calFrom), to:isoDay(calTo||calFrom)};
      closeMenus(); refresh();
      toast('Period set', rangeSummary(F.range)+' — whole months, because the dataset is monthly.');
    }
  });
  placeMenu(m, anchor);
}
const isoDay = d => d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')
  +'-'+String(d.getDate()).padStart(2,'0');
/* Monday-first: this is a UK-English product — "licences", "optimisation". */
const DOW = ['Mo','Tu','We','Th','Fr','Sa','Su'];
function drawCal(m, lo, hi){
  const grid = base => {
    const first = new Date(base.getFullYear(), base.getMonth(), 1);
    const days = new Date(base.getFullYear(), base.getMonth()+1, 0).getDate();
    const lead = (first.getDay()+6)%7;
    let cells = '';
    for(let i=0;i<lead;i++) cells += `<span class="cal-d pad"></span>`;
    for(let dn=1;dn<=days;dn++){
      const d = new Date(base.getFullYear(), base.getMonth(), dn);
      const out = d < lo || d > hi;
      const isEnd = (calFrom && +d===+calFrom) || (calTo && +d===+calTo);
      const between = calFrom && calTo && d>calFrom && d<calTo;
      cells += `<button class="cal-d${isEnd?' end':''}${between?' mid':''}" type="button"
        data-day="${isoDay(d)}"${out?' disabled':''}>${dn}</button>`;
    }
    return `<div class="cal-m">
      <div class="cal-mh">${MONTHS3[base.getMonth()]} ${base.getFullYear()}</div>
      <div class="cal-dow">${DOW.map(x=>`<span>${x}</span>`).join('')}</div>
      <div class="cal-g">${cells}</div></div>`;
  };
  const next = new Date(calCursor.getFullYear(), calCursor.getMonth()+1, 1);
  const canBack = calCursor > new Date(lo.getFullYear(), lo.getMonth(), 1);
  const canFwd  = next < new Date(hi.getFullYear(), hi.getMonth(), 1);
  const resolved = calFrom
    ? rangeSummary({from:isoDay(calFrom), to:isoDay(calTo||calFrom)}) : null;
  m.innerHTML = `
    <div class="cal-h">
      <button class="iconbtn cal-nav back" type="button" data-cal-step="-1"${canBack?'':' disabled'}
              aria-label="Previous month">${icon('caret')}</button>
      <span>Custom range</span>
      <button class="iconbtn cal-nav fwd" type="button" data-cal-step="1"${canFwd?'':' disabled'}
              aria-label="Next month">${icon('caret')}</button>
    </div>
    <div class="cal-body">${grid(calCursor)}${grid(next)}</div>
    <div class="cal-f">
      <span class="cal-note">${resolved
        ? `Resolves to <b>${resolved}</b> · whole months`
        : (closedCount() > 0
            ? `Pick a start, then an end · ${RAW.meta.months[0]}–${RAW.meta.months[closedCount()-1]} available`
            : `No month has closed yet, so there is no range to draw from.`)}</span>
      <span class="cal-acts">
        <button class="btn sm" type="button" data-cal-cancel>Cancel</button>
        <button class="btn sm pri" type="button" data-cal-apply${calFrom?'':' disabled'}>Apply</button>
      </span>
    </div>`;
}
/* Anchors a portalled fixed menu under the control it belongs to.  Measured
   AFTER insertion, because a fixed element's own height is what decides whether
   it can hang below its anchor or has to flip above it. */
function placeMenu(m, anchor){
  const r = anchor.getBoundingClientRect(), h = m.offsetHeight, w = m.offsetWidth;
  const below = r.bottom + 6, flip = below + h > window.innerHeight - 8;
  m.style.top  = (flip ? Math.max(8, r.top - h - 6) : below) + 'px';
  m.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
}

/* The lens picker's list.  A portalled popover on <body> rather than a child of
   its button, for the reason it always was: it hangs off a control inside
   `.navgroups`, which scrolls and therefore clips.  A native <select> could never
   have been styled to match the board either.  Every row navigates, including the
   row you are already on — that is the whole point of replacing the <select>. */
function openViewMenu(anchor){
  const m = document.createElement('div');
  m.className = 'menu vals viewmenu';
  m.dataset.forDim = '__view';
  m.innerHTML = `<div class="menu-h">Viewing As</div>` + Object.keys(PERSONA).map(k=>{
    const v = PERSONA[k];
    return `<button class="menu-opt vp ${k===persona?'on':''}" type="button" data-persona="${k}">
      <span class="vp-t"><b>${v.label}</b><em>${v.blurb}</em></span></button>`;
  }).join('');
  m.addEventListener('click', e=>{
    const o = e.target.closest('[data-persona]'); if(!o) return;
    persona = o.dataset.persona;
    closeMenus();
    /* Leaves the overlay rail open on a narrow screen: you have just changed the
       lens, and the next thing you do is pick a screen through it. */
    go(PERSONA[persona].home);
  });
  document.body.appendChild(m);
  anchor.setAttribute('aria-expanded','true');
  placeMenu(m, anchor);
}
/* A fixed menu does not travel with the pill it belongs to, so it is re-anchored
   whenever the pill could have moved.
   It used to CLOSE instead, which was fine while every menu shut on its first
   click.  Multi-select broke that: narrowing a filter makes the page shorter, the
   browser clamps the scroll position, that fires a scroll event — and the menu
   you were still choosing from vanished on your second tick. */
function repositionMenus(e){
  const m = document.querySelector('.menu.vals');
  if(!m) return;
  /* Scrolling the menu's own option list is not the pill moving. */
  if(e && e.target && e.target.nodeType===1 && m.contains(e.target)) return;
  const dim = m.dataset.forDim;
  const anchor = dim==='__view' ? document.querySelector('[data-view-menu]')
    : document.querySelector('.chip[data-dim="'+(dim==='__range'?'period':dim)+'"]');
  anchor ? placeMenu(m, anchor) : closeMenus();
}
window.addEventListener('scroll', repositionMenus, true);
window.addEventListener('resize', repositionMenus);

document.addEventListener('click', e=>{
  /* a filter pill's clear "×" must not also open the menu */
  const clear = e.target.closest('[data-clear]');
  if(clear){ F[clear.dataset.clear]=[]; closeMenus(); refresh(); return; }
  if(e.target.closest('#clear-filters')){
    MULTI.forEach(k=>F[k]=[]); refresh(); return;
  }
  /* The name half of the split control. Leaves the overlay rail open on a narrow
     screen — you have just changed lens, and the next thing you do is pick a
     screen through it. */
  if(e.target.closest('[data-go-view]')){
    closeMenus();
    if(navOpen()) setNav('mini');
    go(PERSONA[persona].home);
    return;
  }
  const viewBtn = e.target.closest('[data-view-menu]');
  if(viewBtn){
    const mine = document.querySelector('.menu.vals[data-for-dim="__view"]');
    closeMenus(); if(!mine) openViewMenu(viewBtn);
    return;
  }
  const dimChip = e.target.closest('[data-dim]');
  if(dimChip){
    /* The open menu lives on <body>, not inside the pill, so "is mine already
       open?" is answered by the dimension it was built for. */
    const dim = dimChip.dataset.dim;
    const mine = document.querySelector('.menu.vals[data-for-dim="'+dim+'"]');
    closeMenus(); if(!mine) openDimMenu(dimChip, dim);
    return;
  }
  /* The reconciliation strip is permanent chrome, so it has to be dismissible. */
  if(e.target.closest('#ledger-toggle')){ toggleLedger(); return; }
  /* Delegated, not bound: both buttons live inside the screen now and are
     replaced on every render, so a listener attached at boot would be attached
     to a button that no longer exists. */
  if(e.target.closest('#btn-export')){ exportView(); return; }
  if(e.target.closest('#btn-share')){ shareView(); return; }
  /* Open or re-clip a five-item list.  State is per-element and lives on the
     class, so it resets on navigation -- a card that was left open on one screen
     should not decide the height of a grid row on the next. */
  const more = e.target.closest('.rows-more');
  if(more){
    const list = more.parentElement, open = !list.classList.contains('clip');
    list.classList.toggle('clip', open);
    more.textContent = open
      ? `Show all ${more.dataset.total} ${more.dataset.noun}`
      : `Show fewer`;
    return;
  }
  const nav = e.target.closest('[data-go]');
  if(nav){
    closeMenus();
    /* Picking a screen from the floating rail dismisses it — you asked for a
       screen, not for the menu.  Scoped to the sidebar because `data-go` is also
       how the briefing band's "Open backlog" button navigates, and that one is
       not in a menu that needs closing. */
    if(navOpen() && nav.closest('.nav')) setNav('mini');
    go(nav.dataset.go); return;
  }
  const group = e.target.closest('[data-group]');
  if(group){
    const g = group.dataset.group;
    /* In the collapsed rail a group icon is the only affordance there is, so it
       expands the sidebar and opens that group rather than folding it.

       EXPANDING IS ALL IT DOES.  It used to navigate as well — expand, open the
       group, and go to its first screen — on the reasoning that expanding to a
       list you then have to click again is a wasted step.  In use it is the
       opposite: clicking "Spend" to see what is under Spend also threw the
       reader off whatever screen they were reading and onto Cloud, which is a
       destination they never asked for and cannot undo without knowing where
       they were.  "The sidebar should expand only when the user clicks an item."
       So opening the drawer and choosing from it are two separate acts, and the
       cheap one no longer has the expensive one welded to it. */
    if(isMini()){
      setNav('full'); shutGroups.delete(g); renderNav();
      return;
    }
    shutGroups.has(g) ? shutGroups.delete(g) : shutGroups.add(g);
    renderNav(); return;
  }
  const prof = e.target.closest('#profile-btn');
  if(prof){
    const m = document.getElementById('profile-menu');
    const willOpen = m.hidden;
    closeMenus(); m.hidden = !willOpen;
    prof.setAttribute('aria-expanded', String(willOpen));
    return;
  }
  /* composedPath(), not closest().  A menu that redraws itself in its own click
     handler — the calendar does this on every day you pick, the multi-select on
     every value you tick — has already replaced the clicked node by the time the
     event reaches here, and closest() on a detached node walks an orphaned tree
     and answers "not in a menu".  The menu then closed itself on the click that
     was operating it.  composedPath() is captured when the event is dispatched,
     so it still describes where the click actually happened. */
  const path = e.composedPath ? e.composedPath() : [e.target];
  const inMenu = path.some(n=>n && n.classList && n.classList.contains('menu'));
  if(!inMenu) closeMenus();
});
document.addEventListener('keydown', e=>{
  if(e.key!=='Escape') return;
  /* One Escape dismisses one layer: a popover first, then the floating rail. */
  if(document.querySelector('.menu.vals') ||
     !document.getElementById('profile-menu').hidden){ closeMenus(); return; }
  if(navOpen()) setNav('mini');
});

/* Collapsing the reconciliation strip (§7).  The state lives on <html>, not in a
   variable, so it survives every re-render for free — and collapsed still keeps
   the equation on one line rather than hiding it, because a reconciliation figure
   you cannot see is the thing this strip exists to prevent. */
function setLedger(mode){
  if(mode==='min') document.documentElement.setAttribute('data-ledger','min');
  else document.documentElement.removeAttribute('data-ledger');
  const b = document.getElementById('ledger-toggle');
  if(b){ b.dataset.tip = ledgerTip(); b.setAttribute('aria-label', ledgerTip()); }
}
/* What the reader last asked for, as distinct from what scrolling is currently
   imposing.  Without the two being separate, auto-collapsing on scroll would
   silently overwrite a deliberate choice and the strip would never come back. */
let ledgerPref = 'full';
function toggleLedger(){
  ledgerPref = ledgerMin() ? 'full' : 'min';
  setLedger(ledgerPref);
}

/* ---- the pinned state (§8) ----
   Two bars pin at the top of a long screen, and pinned they were wrong in three
   ways at once: a 14px transparent band sat between them with the board sliding
   through it, the strip kept the rounded corners and lift of a card that is
   floating on the page rather than welded to the top of the window, and its
   ticket notches — circles the colour of the canvas — passed over moving content
   and read as holes punched in the board.
   So the pinned state is a different state, not the resting one held in place.
   <html data-stuck> is what says so; the CSS does the rest.

   And the strip COLLAPSES when it pins.  Full height it costs 90px of a scrolled
   screen to restate figures the reader has already passed; collapsed it keeps
   the equation, which is the one thing it exists to keep in view.  The reader's
   own choice still wins: expand it while pinned and it stays expanded.

   THE COLLAPSE MUST NOT CHANGE THE DOCUMENT'S HEIGHT, and the first version did,
   which made it flicker the whole way down a screen.  The loop: collapsing
   removed ~43px of document height, the browser clamped the scroll position to
   the shorter page, the shorter page un-pinned the bar, un-pinning expanded it,
   the document grew again — and it oscillated for as long as you kept scrolling.

   A wide dead band suppresses the flicker but is the wrong fix: it has to be
   wider than the height being removed, which pushed "expand again" down into the
   top ten pixels of the page and left the bar collapsed while it was visibly not
   pinned to anything.

   So the height is RESERVED instead.  Collapsing swaps the height it gives up
   into the margin below it, the document stays exactly as long as it was, and
   nothing can feed back into the scroll position — which lets both transitions
   sit tight against the pin where they belong.  The bar frees room in the
   VIEWPORT, which is the point; it was never the document that needed shortening.
   It still refuses to collapse on a screen barely taller than the viewport,
   where there is no scrolling to make room for.

   Measured from the PAGE HEAD, not from the controls row: the head is never
   sticky, so its position in the document is the one thing here that does not
   move when everything else does.

   Driven by a scroll listener rather than an IntersectionObserver, which is
   what the first version used.  An observer answers "is it pinned" and cannot
   express "is it pinned AND have we passed the point where changing our mind is
   safe" — the second question is the whole fix. */
let stickRaf = 0;
function stickTick(){
  stickRaf = 0;
  const html = document.documentElement;
  const ctl = document.querySelector('.controls');
  const head = document.querySelector('#screen > .pagehead');
  /* Cleared, not left alone.  A screen that emits no controls row — sign-in, and
     the ones that compose their own head — has nothing to pin, and a data-stuck
     left over from the previous screen would apply the pinned treatment to a
     page that is pinned to nothing. */
  if(!ctl || !head){
    html.removeAttribute('data-stuck');
    setLedger(ledgerPref);
    return;
  }
  const y = window.scrollY;
  /* Where the controls row starts pinning: the foot of the page head plus its
     6px margin.  Recomputed each tick and self-correcting, which matters because
     a filter change can reflow the head without a navigation. */
  const pin = head.getBoundingClientRect().bottom + y + 6;

  /* data-stuck flips exactly at the pin, and may: the pinned treatment swaps
     14px of margin for 14px of padding, so it changes no height and cannot feed
     back into the scroll position. */
  html.toggleAttribute('data-stuck', y > pin);

  /* WHERE THE STRIP COMES TO REST, measured off the bar it rests under.
     The strip's `top` was the constant --controls-h, which is the row's RESTING
     height — pinned, the row is height:auto plus 12/18 of padding and stands
     14px taller, so the strip parked that far underneath it and the opaque bar
     (z-index 18 against its 12) painted over its top edge.  A second constant
     would have fixed today's numbers and drifted again on the next change to a
     chip, a font size or a breakpoint, so the row is measured instead and the
     stylesheet reads the answer.
     Setting a custom property cannot reflow anything by itself, and the value
     it feeds — a sticky `top` — changes where the strip stops, never how tall
     the document is.  So this is safe to do inside the scroll handler; nothing
     here can feed back into the scroll position the way the collapse once did. */
  html.style.setProperty('--stuck-h', Math.round(ctl.getBoundingClientRect().height) + 'px');

  const roomy = html.scrollHeight - window.innerHeight > 260;
  const min = ledgerMin();
  if(!min && roomy && y > pin + 8)   collapseLedger();
  else if(min && y < pin - 8)        expandLedger();
  else if(min && !roomy)             expandLedger();
}
/* Measured rather than assumed: the strip's collapsed and expanded heights both
   depend on the figures in it, the palette and the window width, so a constant
   here would be wrong on the first screen that disagreed with it. */
function collapseLedger(){
  const led = document.querySelector('.ledger');
  if(!led) { setLedger('min'); return; }
  const full = led.getBoundingClientRect().height;
  setLedger('min');
  const gap = parseFloat(getComputedStyle(document.documentElement)
    .getPropertyValue('--grid-gap')) || 22;
  led.style.marginBottom = (gap + full - led.getBoundingClientRect().height) + 'px';
}
function expandLedger(){
  const led = document.querySelector('.ledger');
  if(led) led.style.marginBottom = '';
  setLedger(ledgerPref);
}
const stickCheck = () => { if(!stickRaf) stickRaf = requestAnimationFrame(stickTick); };
window.addEventListener('scroll', stickCheck, {passive:true});
window.addEventListener('resize', stickCheck);
function watchStick(){ stickTick(); }

/* ---- Sidebar states (§8) ----
   Three, not two, and which two are reachable depends on the width:

     full     the 276px rail, in the layout          (wide only)
     mini     the 76px icon rail, in the layout      (both)
     open     the full rail FLOATING over the board  (narrow only)

   The third state exists because the mock-up had a real hole: below 1180px the
   stylesheet hard-forces the mini rail, and the expand control was itself hidden
   there — so on a tablet the seventeen screen names could not be reached at all.
   "It can be expanded and collapsed only in a wider desktop view.  When switching
   to a tablet view, it appears only in a collapsed state, preventing users from
   accessing the sub-items."
   Widening the column in place was the obvious fix and is wrong: 276px of nav out
   of 1000px leaves a board too narrow to read, and every card would reflow twice
   per toggle.  Floating it leaves the mini rail's 76px in the layout, so opening
   and closing the sidebar moves nothing underneath it.

   The attribute carries only the DEVIATION from each width's default, which is
   what lets a window resize be harmless: unset means "whatever this width does
   normally", and the stylesheet's own media query supplies that. */
const NARROW = () => window.matchMedia('(max-width:1180px)').matches;
const navOpen = () => document.documentElement.getAttribute('data-nav')==='open';
/* "Is the rail currently showing icons only" — which is what the group-header
   click needs to know, and it is a question about what is on screen, not about
   which attribute is set. */
const isMini = () => !navOpen() &&
  (document.documentElement.getAttribute('data-nav')==='mini' || NARROW());
function setNav(mode){
  const h = document.documentElement;
  if(mode==='full') NARROW() ? h.setAttribute('data-nav','open') : h.removeAttribute('data-nav');
  else              NARROW() ? h.removeAttribute('data-nav')     : h.setAttribute('data-nav','mini');
}
document.getElementById('nav-collapse').addEventListener('click', ()=>setNav('mini'));
document.getElementById('nav-expand').addEventListener('click', ()=>setNav('full'));
document.getElementById('nav-scrim').addEventListener('click', ()=>setNav('mini'));
/* Crossing the breakpoint with the overlay open would leave a floating panel
   stranded over a layout that has room for it inline. */
window.addEventListener('resize', ()=>{ if(navOpen() && !NARROW()) setNav('mini'); });

document.addEventListener('change', e=>{
  if(e.target.id==='scenario'){
    loadScenario(e.target.value); refresh(); toast('Loaded '+RAW.label, RAW.blurb);
    finnNudge();
  }
});

/* FINN'S ONE PULSE.  Finn is frozen while the conversation is closed — that is the
   `docked` state, and stillness there is a rule rather than an omission (see the
   motion block at the foot of styles.css §12).  Its single exception is `alert`: one
   pulse, once, when something has arrived worth a glance.
   Loading a workspace is the one moment in the mock-up when that is genuinely true,
   so it is the only place this fires, and only when the workspace being loaded
   actually has open alerts.  A pulse over an empty alert feed would be the inert
   control §0.7 forbids, dressed up as motion. */
function finnNudge(){
  if(!(RAW.alerts||[]).length) return;
  if(typeof finnAlert === 'function') finnAlert();
}

document.getElementById('menu-notif').addEventListener('click', ()=>{ closeMenus(); go('alerts'); });
document.getElementById('menu-signout').addEventListener('click', ()=>{
  closeMenus(); go('signin');
  toast('Signed out','See you next time.');
});
/* Loading a real .json file.  fetch() of a local file is blocked from a file://
   origin, so FileReader is the only route that works when the mock-up is opened
   by double-click.  See data/SCHEMA.md. */
document.getElementById('menu-load').addEventListener('click', ()=>{
  closeMenus(); document.getElementById('json-file').click();
});
document.getElementById('json-file').addEventListener('change', e=>{
  const f = e.target.files[0]; if(!f) return;
  const r = new FileReader();
  r.onload = () => {
    try{
      const payload = JSON.parse(r.result);
      if(!payload.id || !payload.categories) throw new Error('not a Finoptic dataset');
      loadScenario(FINOPTIC.adopt(payload));
      refresh();
      toast('Loaded '+(payload.label||payload.id), f.name+' · '+(payload.blurb||''));
      finnNudge();
    }catch(err){
      toast('Could not read that file', err.message+' — see data/SCHEMA.md for the expected shape.');
    }
    e.target.value = '';
  };
  r.readAsText(f);
});

/* Accent palette switcher — demo-only, and now inside the profile menu rather
   than sitting in the nav looking like a developer control.  Swaps the whole
   brand accent by setting data-palette on <html>; see the [data-palette] blocks
   in styles.css.  Storage is wrapped: some browsers refuse localStorage on a
   file:// origin, and losing persistence must not take the switcher down. */
(function(){
  const sel = document.getElementById('palette-switch');
  const store = {
    get(){ try{ return localStorage.getItem('finoptic-palette'); }catch(e){ return null; } },
    set(v){ try{ localStorage.setItem('finoptic-palette', v); }catch(e){ /* session only */ } }
  };
  const saved = store.get() || 'orange';
  document.documentElement.setAttribute('data-palette', saved);
  sel.value = saved;
  sel.addEventListener('change', e=>{
    document.documentElement.setAttribute('data-palette', e.target.value);
    store.set(e.target.value);
  });
})();

/* ---- boot ----
   A shared link carries the whole view in its hash, so it is restored before
   the first render rather than being navigated to afterwards. */
function restore(){
  const raw = location.hash.slice(1);
  const [screen,qs] = raw.split('?');
  const p = new URLSearchParams(qs||'');
  const sid = p.get('s');
  loadScenario(sid && FINOPTIC.list.some(x=>x.id===sid) ? sid : FINOPTIC.list[0].id, true);
  if(p.get('v') && PERSONA[p.get('v')]) persona = p.get('v');
  /* Every filter is SET from the link, including to nothing.  This used to only
     assign when the parameter was present, so following a link with no product
     filter from a page that had one kept the old one — the URL and the screen
     then disagreed, and the leaked filter narrowed figures nobody had asked to
     narrow.  A shared link describes the whole view or it describes none of it. */
  MULTI.forEach(k=>{
    const v = p.get(k);
    F[k] = v ? v.split(',').filter(Boolean) : [];
  });
  F.period = p.get('period') || PERIODS[0][0];
  const r = p.get('range');
  F.range = (F.period===CUSTOM_PERIOD && r && r.includes('~'))
    ? {from:r.split('~')[0], to:r.split('~')[1]} : null;
  /* A custom period with no range restored is a period that means nothing, so it
     falls back rather than silently resolving to the full year under a chip that
     still says "Custom". */
  if(F.period===CUSTOM_PERIOD && !F.range) F.period = PERIODS[0][0];
  /* WITH NO LINK TO RESTORE, OPEN ON SIGN-IN.  It is the product's front door, so
     it is the product's home page, and a demo that starts there tells the story in
     the order a customer would meet it.
     Two earlier defaults and why they went: the active view's home screen, which
     meant a cold start landed on IT financial management — a persona screen chosen
     by a dropdown nobody had touched; and then the Executive overview, which is
     still the first screen you see after signing in and is still what makes the
     sidebar's fold state coherent (Overview is the only group that opens — see
     shutGroups).  Sign-in simply comes before it.
     A shared link still wins — `screen` comes from the hash — so every URL in
     circulation opens on the board it names rather than on a login. */
  return screen || 'signin';
}
fillChrome();
const start = restore();
go(start, false);
/* Hands the cold-start preloader its cue.  motion.js raises the veil at load,
   before anything has rendered; it is lowered from HERE, once the first screen is
   in the DOM, so what the veil lifts off is a finished board rather than a blank
   one.  Optional like the rest of MOTION — motion.js arms its own failsafe
   timer, because a splash screen that never lifts is the single failure a demo
   cannot survive. */
if(window.MOTION) MOTION.boot();
/* Restores state from a link pasted while the page is already open. */
window.addEventListener('hashchange', ()=>{ const id = restore(); go(id,false); });
